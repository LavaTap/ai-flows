/* account-repo.js · 管线设置页脚本（给当前仓库配 GitHub 链接） */
(function () {
  var boot = window.__ACCOUNT_REPO__ || {};
  var user = boot.user || {};
  var isSuper = !!boot.isSupervisor;
  var state = { githubUrl: boot.githubUrl || "", ownerRepo: boot.ownerRepo || "" };

  /* ────────────── 工具函数 ────────────── */

  function byId(id) { return document.getElementById(id); }

  function colorOf(email) {
    var s = String(email || ""); var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    return "hsl(" + (h % 360) + ", 55%, 55%)";
  }

  function firstChar(u) {
    if (u.name && u.name.length) return u.name.charAt(0);
    return u.email ? u.email.charAt(0).toUpperCase() : "?";
  }

  function post(url, body) {
    var init = { method: "POST", headers: { "Content-Type": "application/json" } };
    if (body !== undefined) init.body = JSON.stringify(body);
    return fetch(url, init).then(function (r) {
      return r.json().then(function (d) { return { ok: r.ok, status: r.status, data: d }; });
    });
  }

  /* ────────────── 顶栏 ────────────── */

  function initTopbar() {
    if (isSuper) {
      var teamLink = byId("teamLink");
      if (teamLink) teamLink.style.display = "inline-block";
    }
    var chip = document.querySelector(".user-chip");
    if (chip) {
      var av = chip.querySelector(".avatar");
      if (av) {
        if (user.avatar) {
          av.style.background = "none";
          av.innerHTML = '<img src="/api/avatars/' + user.avatar + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" alt="">';
        } else {
          av.style.background = colorOf(user.email);
          av.textContent = firstChar(user);
        }
      }
    }
    var nameEl = byId("userName");
    if (nameEl) nameEl.textContent = user.name || user.email || "";
  }

  /* ────────────── 仓库信息 + 表单 ────────────── */

  function renderRepo() {
    byId("repoPathEl").textContent = boot.repoPath || "—";
    byId("repoNameEl").textContent = boot.repoName || "—";
  }

  function renderPreview() {
    var el = byId("ownerRepoEl");
    el.textContent = state.ownerRepo ? "/" + state.ownerRepo : "（未配置，显示本地目录名）";
  }

  function setMsg(text, cls) {
    var el = byId("repoMsg");
    el.textContent = text || "";
    el.className = "form-msg" + (cls ? " " + cls : "");
  }

  function save(url) {
    var btn = byId("repoSubmit");
    btn.disabled = true;
    setMsg("");
    post("/api/repo/github", { url: url }).then(function (res) {
      btn.disabled = false;
      if (res.ok && res.data) {
        state.githubUrl = res.data.githubUrl || "";
        state.ownerRepo = res.data.ownerRepo || "";
        byId("githubUrl").value = state.githubUrl;
        renderPreview();
        setMsg(state.githubUrl ? "已保存，管线页左侧将显示 /" + state.ownerRepo : "已清除配置", "ok");
      } else {
        setMsg((res.data && res.data.error) || "保存失败", "err");
      }
    }).catch(function () {
      btn.disabled = false;
      setMsg("保存失败，请稍后重试", "err");
    });
  }

  function initForm() {
    byId("githubUrl").value = state.githubUrl;
    renderPreview();

    byId("repoForm").addEventListener("submit", function (e) {
      e.preventDefault();
      save(byId("githubUrl").value.trim());
    });

    byId("repoClear").addEventListener("click", function () {
      byId("githubUrl").value = "";
      save("");
    });
  }

  /* ────────────── 启动 ────────────── */

  initTopbar();
  renderRepo();
  initForm();
})();